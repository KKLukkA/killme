#include "main.h"
#include "dlib/dlib.hpp"
#include "liblvgl/llemu.hpp"
#include "pros/adi.hpp"
#include "pros/llemu.hpp"
#include "pros/misc.h"
#include "pros/motor_group.hpp"
#include "pros/motors.h"
#include "pros/rtos.h"
#include "pros/rtos.hpp"

// ** CLANGD IS RECOMMENDED ** //

// Robot Constructor
// Initialize your robot inside of this constructor!
pros::Motor intakeMotor(-6,pros::v5::MotorGears::blue);
pros::adi::DigitalOut mogo('h', false);
pros::adi::DigitalOut fart('f', false);
pros::Motor BlackWoaman1 (3);
pros::Motor BlackWoaman2 (-8);
pros::MotorGroup BlackWomanMech ({3,-8});

bool wingsActive = false;
bool cornerclear = false;

struct Robot {
        dlib::Chassis chassis = dlib::Chassis(
		{-14,-4,-15},
    	{18,12,13},
    	3.25,
    	450
    );


    dlib::IMU imu = dlib::IMU(
        16,
        // IMU return scalar
        1.01107975
    );

    // Create a new PID for whatever you need!
    dlib::PID drive_pid = dlib::PID(
        // Adjust each gain for a more accurate PID.
        // kp, ki, kd
        {25,0,3},
        10
    );

    dlib::PID turn_pid = dlib::PID(
        // kp, ki, kd
        {-2,0,-0.9},
        1
    );

    dlib::FeedForward drive_feed_forward = dlib::FeedForward(
        {0,0,0}
    );

    dlib::FeedForward turn_feed_forward = dlib::FeedForward(
        {0,0,0}
    );

    dlib::Odom odom = dlib::Odom();

    dlib::Chassis& get_chassis() {
        return chassis;
    }

    dlib::IMU& get_imu() {
        return imu;
    } 

    dlib::PID& get_drive_pid() {
        return drive_pid;
    }

    dlib::PID& get_turn_pid() {
        return turn_pid;
    } 

    dlib::Odom& get_odom() {
        return odom;
    }
};

// instantiate a Robot object
Robot robot = Robot();

// instantiate a Position struct
dlib::Position position = dlib::get_position(robot, false);

// instantiate a Controller object
pros::Controller master(pros::E_CONTROLLER_MASTER);



void initialize() {
    dlib::calibrate(robot);
    pros::lcd::initialize();
    dlib::start_odom_update_loop(robot);
    

}

void disabled() {}

void competition_initialize() {}



void autonomous() {
 // try some movements!

  /*  dlib::move_inches(robot,24,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 99999,
    .max_voltage = 12000
    }
    ); */
   // Basic 1 tile forward movement ^

    /* dlib::turn_degrees(robot,90,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 3000,
    .max_voltage = 12000
    } //turn to rings
    ); */

   /* dlib::move_to(robot, 0, 1, true,{
     .error_threshold = 1,
     .settle_ms = 200,
     .max_ms = 1000,
     .max_voltage = 12000},
     {
     .error_threshold = 1,
     .settle_ms = 200,
     .max_ms = 1000,
     .max_voltage = 12000}

     ); */
     
   /* / dlib::move_inches(robot,-36,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    }// killmyself
    ); */


   // RED RIGHT SIDE AUTO slot 1 !!!!!!!
    
   /* BlackWomanMech.move(120);
    pros::delay (100);
    BlackWomanMech.move(0);
    
    dlib::move_inches(robot,-26,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // go to first mogo
    ); 
    
    mogo.set_value(true); //grab

    intakeMotor.move(-12000); //intake nonstop
    pros::delay(1000);

    dlib::turn_degrees(robot,-65,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } //turn to rings
    ); 

    dlib::move_inches(robot,25,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // go to rings
    ); 

    pros::delay(5000); 
   
    /* dlib::turn_degrees(robot,0,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } //turn to other rings
    ); 

    dlib::move_inches(robot,26,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // go to the other rings  

    );
    
    //!!!!!!!!!!!!!! */ 

    // RED LEFT SIDE AUTO slot 2 !!!!!!!!!!!

   /* BlackWomanMech.move(120);
    pros::delay (100);
    BlackWomanMech.move(0);

    dlib::move_inches(robot,-6,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // drive to align to the robot 
    ); 
    
    dlib::turn_degrees(robot,30,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } //turn to first mogo
    ); 


    dlib::move_inches(robot,-29,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // go to first mogo
    ); 

    mogo.set_value(true); // grab mogo
    intakeMotor.move(-12000); //intake nonstop
    pros::delay(1000);

    dlib::move_inches(robot,5,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    }// go forward a little
    ); 

    dlib::turn_degrees(robot,92,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } // turn to donuts
    ); 

    dlib::move_inches(robot,20,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go to donuts
    ); 
    // intake donuts

   dlib::turn_degrees(robot,180,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } // turn to donuts near line
    ); 

    dlib::move_inches(robot,14,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 2500 
    } // go to donuts near line
    ); 

    dlib::move_inches(robot,-7,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 2500 
    } // go to donuts near line
    ); 

    dlib::turn_degrees(robot,160,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } // turn to donuts near line
    ); 
    
    dlib::move_inches(robot,10,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 2500 
    } // go to donuts near line
    ); 

    //!!!!!!!!!!!!!!!!! */
    

    //BLUE RIGHT SIDE AUTO slot 4 !!!!!!! 
   
   /* BlackWomanMech.move(120);
    pros::delay (100);
    BlackWomanMech.move(0);
   
    dlib::move_inches(robot,-6,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // drive to align to the robot 
    ); 


    dlib::turn_degrees(robot,-30,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } //turn to first mogo
    ); 


    dlib::move_inches(robot,-29,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // go to first mogo
    ); 

    mogo.set_value(true); // grab mogo
    intakeMotor.move(-12000); //intake nonstop
    pros::delay(1000);

    dlib::move_inches(robot,5,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    }// go forward a little
    ); 

    dlib::turn_degrees(robot,-92,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } // turn to donuts
    ); 

    dlib::move_inches(robot,20,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // go to donuts
    ); 
    // intake donuts

    dlib::turn_degrees(robot,-180,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } // turn to donuts near line
    ); 

    dlib::move_inches(robot,14,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 2500 
    } // go to donuts near line
    ); 

    dlib::move_inches(robot,-7,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 2500 
    } // go to donuts near line
    ); 

    dlib::turn_degrees(robot,-160,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } // turn to donuts near line
    ); 
    
    dlib::move_inches(robot,10,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 2500 
    } // go to donuts near line
    ); 

    //!!!!!!!!!!!!!!!!!!!!!!!!!! */


// BLUE LEFT SIDE AUTO slot 3 !!!!!!!!!!!
     
 /*   BlackWomanMech.move(120);
    pros::delay (100);
    BlackWomanMech.move(0);

    dlib::move_inches(robot,-26,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // go to first mogo
    ); 
    
    mogo.set_value(true); //grab

    intakeMotor.move(-12000); //intake nonstop
    pros::delay(1000);

    dlib::turn_degrees(robot,65,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 12000
    } //turn to rings
    ); 

    dlib::move_inches(robot,24,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // go to rings
    ); 

    dlib::move_inches(robot,-5,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 2000
    } // go to rings
    ); 

    pros::delay(8000); 
    intakeMotor.move(0); //intake stop */

   //////!!!!!!!!!!! */

     //SKILLS AUTON WIP slot 5 !!!!!!!!!!!!!
    

    BlackWomanMech.move(120);
    pros::delay (100);
    BlackWomanMech.move(0);

    // CORNER LEFT SIDE RED START

    dlib::move_inches(robot,-10,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go forwar for rings
    ); 


    mogo.set_value(true); //grab

    intakeMotor.move(-12000);
    pros::delay(500);

    dlib::turn_degrees(robot,189,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to RINGS 1st turn 
    ); 

   dlib::turn_degrees(robot,186,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to RINGS 1st turn ORIGINAL
    ); 

    pros::delay(500);

    dlib::move_inches(robot,30,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go forwar for rings
    ); 

    pros::delay(1000);

    dlib::turn_degrees(robot,140,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to  rings NEAR LADDER- 2nd turn 
    );  

    dlib::move_inches(robot,24,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go forwrd for rings 
    ); 

    dlib::turn_degrees(robot,44,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to the left for more 3rd turn
    );  

    dlib::move_inches(robot,20,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go forwrd for rings x1 
    ); 

    dlib::move_inches(robot,15,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go forwrd for rings x2
    ); 

    dlib::turn_degrees(robot,70,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn a little for side ring 
    );  

    dlib::move_inches(robot,-10,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go back a little 
    ); 


    dlib::turn_degrees(robot,120,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to more rings
    );  

    dlib::move_inches(robot,13,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go forwrd for rings n finsih corner 
    ); 

    dlib::move_inches(robot,-13,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go back a little 
    ); 

    dlib::turn_degrees(robot,270,{ 
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to corner 
    );  

    dlib::move_inches(robot,-20,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go back to drop  
    ); 

    intakeMotor.move(0);
    
    mogo.set_value(false); //let go

    dlib::move_inches(robot,17,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go up
    ); 
    
    dlib::turn_degrees(robot,135,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to drive backwards
    );  

    dlib::move_inches(robot,-60,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go back 
    ); 

    pros::delay(1000); 
    

    //SECOND HALF

    mogo.set_value(true); //lgraboo


   /* / dlib::turn_degrees(robot,110,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to facr right side rings 
    );   //CHANGE

    intakeMotor.move(-12000);

    dlib::move_inches(robot,22,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go up
    );  

    dlib::turn_degrees(robot,137,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to facr right side rings 
    );  //CHANGE

    dlib::move_inches(robot,32,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go TO MIDDLE RING ON right side 
    ); 

    dlib::turn_degrees(robot,240,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to facr right side rings 
    );  //CHANGE

    dlib::move_inches(robot,15,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go TO  RING ON right side 
    ); 

    dlib::turn_degrees(robot,274,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to facr right side rings 
    );  //CHANGE

    dlib::move_inches(robot,28,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go TO  RING ON right side 
    ); 

    dlib::move_inches(robot,10,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go TO  RING ON right side 
    ); 

    dlib::turn_degrees(robot,230,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to facr right side rings 
    );  //CHANGE

    dlib::move_inches(robot,-10,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go TO  RING ON right side 
    ); 

    dlib::turn_degrees(robot,185,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to facr right side far rings 
    );  //CHANGE
    
    dlib::move_inches(robot,15,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go TO  RING ON right side 
    ); 

    dlib::move_inches(robot,-15,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go BACK FROM  RING ON right side 
    ); 
    
    dlib::turn_degrees(robot,45,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // turn to facr right side far rings 
    );  //CHANGE

    pros::delay(850);
    intakeMotor.move(0);

    dlib::move_inches(robot,-18,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go BACK FROM  RING ON right side 
    ); 

    mogo.set_value(false); //lgraboo

    dlib::move_inches(robot,18,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 6000
    } // go BACK FROM  RING ON right side 
    ); 

    //!!!!!!!!!!!!!!!!!!!!!!!!!!!! */



    //!!!BASIC COMMANDS 4 DLIB!!!!!!

    /*  dlib::turn_degrees(robot,90,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 99999,
    .max_voltage = 12000
    }
    ); */
    //basic 90 degree turn ^

/* dlib::move_to(robot, 5, 0, true,{
     .error_threshold = 0,
     .settle_ms = 200,
     .max_ms = 99999,
     .max_voltage = 12000},
     {
     .error_threshold = 0,
     .settle_ms = 200,
     .max_ms = 99999,
     .max_voltage = 12000}

     ); */ // Basic move command ^

  /* dlib::move_inches(robot,24,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 99999,
    .max_voltage = 12000
    }
    ); */
   // Basic 1 tile forward movement ^
}



void opcontrol() {
    dlib::set_mode_brake(robot);
    while(true){

        if(master.get_digital(DIGITAL_L1)){
            intakeMotor.move_voltage(12000);
        }
        
        // Intake Code
        // If L2 is held down, motor = max reverse speed
        else if(master.get_digital(DIGITAL_L2)){
            intakeMotor.move_voltage(-12000);
        }

         // Intake Code
         // Otherwise, dont move at all
        else{
            intakeMotor.move(0);
        }

        // Press A to grab, press again to let go of Mobile Goal
        if(master.get_digital_new_press(DIGITAL_A)){
            wingsActive = !wingsActive;
    
        }

        mogo.set_value(wingsActive);

        if(master.get_digital(DIGITAL_Y)){
            cornerclear = !cornerclear;

            fart.set_value(cornerclear);

            /*if(cornerclear)
                fart.set_value(HIGH);
            else
                fart.set_value(LOW);
            pros::delay(500);*/
        }

        if(master.get_digital(DIGITAL_R2)) //runs motor forward
        {
            BlackWomanMech.move(120);
        }
        else if(master.get_digital(DIGITAL_R1)) //runs motor backward
        { 
            BlackWomanMech.move(-120);
        }
        else 
        {
            BlackWomanMech.set_brake_mode(pros::E_MOTOR_BRAKE_BRAKE); //not pressing anything= everything stops
            BlackWomanMech.brake();
        }

         if(master.get_digital(DIGITAL_B)){ //LOADING STAGE FOR BROWNLADY

            BlackWomanMech.move(127);
            pros::delay(45);
            BlackWomanMech.move(0);

            }
        // basic arcade using dLib
        double power = master.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
        double turn = master.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_X);
        dlib::arcade(robot, power, turn);

        // to change the left.move / right.move go itno dlib hpp

        dlib::Position position = robot.get_odom().get_position();
        pros::lcd::print(0,"X: %f", position.x);
        pros::lcd::print(1,"Y: %f", position.y);
        pros::delay(20);

        pros::delay(20);
    }
    }
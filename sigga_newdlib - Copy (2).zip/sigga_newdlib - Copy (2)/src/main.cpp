#include "main.h"
#include "dlib/dlib.hpp"
#include "liblvgl/llemu.hpp"
#include "pros/adi.hpp"
#include "pros/misc.h"
#include "pros/rtos.hpp"

// ** CLANGD IS RECOMMENDED ** //

// Robot Constructor
// Initialize your robot inside of this constructor!
pros::Motor intakeMotor(-6,pros::v5::MotorGears::blue);
pros::adi::DigitalOut mogo('h', false);

struct Robot {
        dlib::Chassis chassis = dlib::Chassis(
		{-14,-4,-15},
    	{18,12,13},
    	3.25,
    	450
    );


    dlib::IMU imu = dlib::IMU(
        17,
        // IMU return scalar
        1.01107975
    );

    // Create a new PID for whatever you need!
    dlib::PID drive_pid = dlib::PID(
        // Adjust each gain for a more accurate PID.
        // kp, ki, kd
        {25,0,3},
        10
    );

    dlib::PID turn_pid = dlib::PID(
        // kp, ki, kd
        {-5,0,-0.1},
        1
    );

    dlib::FeedForward drive_feed_forward = dlib::FeedForward(
        {0,0,0}
    );

    dlib::FeedForward turn_feed_forward = dlib::FeedForward(
        {0,0,0}
    );

    dlib::Odom odom = dlib::Odom();

    dlib::Chassis& get_chassis() {
        return chassis;
    }

    dlib::IMU& get_imu() {
        return imu;
    } 

    dlib::PID& get_drive_pid() {
        return drive_pid;
    }

    dlib::PID& get_turn_pid() {
        return turn_pid;
    } 

    dlib::Odom& get_odom() {
        return odom;
    }
};

// instantiate a Robot object
Robot robot = Robot();

// instantiate a Position struct
dlib::Position position = dlib::get_position(robot, false);

// instantiate a Controller object
pros::Controller master(pros::E_CONTROLLER_MASTER);

void initialize() {
    dlib::calibrate(robot);
    pros::lcd::initialize();
    dlib::start_odom_update_loop(robot);
}

void disabled() {}

void competition_initialize() {}

void autonomous() {
 // try some movements!

  /*  dlib::move_inches(robot,24,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 99999,
    .max_voltage = 12000
    }
    ); */
   // Basic 1 tile forward movement ^
     

     dlib::turn_degrees(robot,90,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 99999,
    .max_voltage = 12000
    }
    ); 
}


bool wingsActive = false;

void opcontrol() {
    while(true){
        // Update position struct
        position = dlib::get_position(robot, false);

        if(master.get_digital(DIGITAL_L1)){
            intakeMotor.move_voltage(12000);
        }
        
        // Intake Code
        // If L2 is held down, motor = max reverse speed
        else if(master.get_digital(DIGITAL_L2)){
            intakeMotor.move_voltage(-12000);
        }

         // Intake Code
         // Otherwise, dont move at all
        else{
            intakeMotor.move(0);
        }

        // Press A to grab, press again to let go of Mobile Goal
        if(master.get_digital_new_press(DIGITAL_A)){
            wingsActive = !wingsActive;
        }

        mogo.set_value(wingsActive);

        // basic arcade using dLib
        double power = master.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
        double turn = master.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_X);
        dlib::arcade(robot, power, turn);

        // to change the left.move / right.move go itno dlib hpp

        pros::lcd::set_text(1, std::to_string(position.x));

        pros::delay(20);
    }
    }
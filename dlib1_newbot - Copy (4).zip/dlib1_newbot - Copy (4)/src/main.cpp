#include "main.h"
#include "dlib/dlib.hpp"
#include "liblvgl/llemu.hpp"
#include "pros/adi.hpp"
#include "pros/llemu.hpp"
#include "pros/misc.h"
#include "pros/motor_group.hpp"
#include "pros/motors.h"
#include "pros/rotation.hpp"
#include "pros/rtos.h"
#include "pros/rtos.hpp"
#include "lift.hpp"

// ** CLANGD IS RECOMMENDED ** //

// Robot Constructor
// Initialize your robot inside of this constructor!
pros::Motor intakeMotor(-6,pros::v5::MotorGears::blue);
pros::adi::DigitalOut mogo('h', false);
pros::adi::DigitalOut fart('f', false);
pros::adi::DigitalOut shit('a', false);
pros::Motor BlackWoaman1 (10);
pros::Motor BlackWoaman2 (-7);
pros::MotorGroup BlackWomanMech ({10,-7}); 
pros::Rotation rotsen(11);
Lift lift(
-7, 
10,
'H'
);
bool wingsActive = false;
bool cornerclear = false;
bool testicles = false;

struct Robot {
        dlib::Chassis chassis = dlib::Chassis(
		{-17,5,-15},
    	{-18,12,13},
    	3.25,
    	450
    );


    dlib::IMU imu = dlib::IMU(
        4,
        // IMU return scalar
        1
    );

    // Create a new PID for whatever you need!
    dlib::PID drive_pid = dlib::PID(
        // Adjust each gain for a more accurate PID.
        // kp, ki, kd
        {25,0,3},
        10
    );

    dlib::PID turn_pid = dlib::PID(
        // kp, ki, kd
        {-2,0,-0.9},
        1
    );

    dlib::FeedForward drive_feed_forward = dlib::FeedForward(
        {0,0,0}
    );

    dlib::FeedForward turn_feed_forward = dlib::FeedForward(
        {0,0,0}
    );

    dlib::Odom odom = dlib::Odom();

    dlib::Chassis& get_chassis() {
        return chassis;
    }

    dlib::IMU& get_imu() {
        return imu;
    } 

    dlib::PID& get_drive_pid() {
        return drive_pid;
    }

    dlib::PID& get_turn_pid() {
        return turn_pid;
    } 

    dlib::Odom& get_odom() {
        return odom;
    }
};

// instantiate a Robot object
Robot robot = Robot();

// instantiate a Position struct
dlib::Position position = dlib::get_position(robot, false);

// instantiate a Controller object
pros::Controller master(pros::E_CONTROLLER_MASTER);



void initialize() {
    dlib::calibrate(robot);
    pros::lcd::initialize();
    dlib::start_odom_update_loop(robot);
    
    

}

void disabled() {}

void competition_initialize() {}



void autonomous() {
 // try some movements!

    /* dlib::move_inches(robot,24,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 999999,
    .max_voltage = 12000
    }
    ); 
    /* dlib::move_inches(robot,-24,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 2000,
    .max_voltage = 12000
    }
    );*/
   // Basic 1 tile forward movement ^

    /* dlib::turn_degrees(robot,87,{
    .error_threshold = 0,
    .settle_ms = 10000,
    .max_ms = 20000,
    .max_voltage = 12000
    } //turn to rings
    ); 

   /* dlib::move_to(robot, 0, 1, true,{
     .error_threshold = 1,
     .settle_ms = 200,
     .max_ms = 1000,
     .max_voltage = 12000},
     {
     .error_threshold = 1,
     .settle_ms = 200,
     .max_ms = 1000,
     .max_voltage = 12000}

     ); */
     
   /* / dlib::move_inches(robot,-36,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    }// killmyself
    ); */


   // RED RIGHT SIDE AUTO slot 1 !!!!!!! working 2/21

    /* dlib::move_inches(robot,-29,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 650,
    .max_voltage = 12000
    } // go to first mogo
    ); 

    dlib::turn_degrees(robot,-25,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 300,
    .max_voltage = 12000
    } //turn to middle rings
    ); 

    dlib::move_inches(robot,-21,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 750,
    .max_voltage = 7000
    } // go to middle mogo
    ); 

    mogo.set_value(true); // grab mog
    intakeMotor.move(12000); //intake nonstop
    pros::delay(150);
    
    dlib::move_inches(robot,5,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 600,
    .max_voltage = 6000
    } // go up a litt w/ mogo
    ); 

    dlib::turn_degrees(robot,15,{ //WASa
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 550,
    .max_voltage = 12000
    } //turn to rings  
    ); 

    dlib::move_inches(robot,19,{ //changed form 30
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 12700
    } // ram the secondary ring
    ); 

    dlib::move_inches(robot,-5,{ //changed form 30
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 400,
    .max_voltage = 7000
    } // go up a litt w/ mogo
    ); 

    mogo.set_value(false); // ungrab mog
    intakeMotor.move(0); //intake nonstop

    dlib::move_inches(robot,5,{ //changed form 30
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 400,
    .max_voltage = 12000
    } // go up a litt w/ mogo
    ); 

    dlib::turn_degrees(robot,-63,{ //WASa
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 550,
    .max_voltage = 12000
    } //turn to rings  
    );

    
    dlib::move_inches(robot,-18,{ //changed form 30
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // go up a litt w/ mogo
    ); 

   mogo.set_value(true); // grab mog

    dlib::move_inches(robot,24.5,{ //changed form 30
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 950,
    .max_voltage = 12000
    } // go up a litt w/ mogo
    ); 

    dlib::turn_degrees(robot,-28,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 550,
    .max_voltage = 12000
    } //turn to rings  
    ); 
    
    intakeMotor.move(12000); //intake nonstop

    dlib::move_inches(robot,39,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1800,
    .max_voltage = 7000
    } // go up a litt w/ mogo
    ); 

    dlib::move_inches(robot,-10,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 1500,
        .max_voltage = 10000
        } // go back a little w/ mogo
        ); 
    
        dlib::move_inches(robot,5,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 1500,
        .max_voltage = 10000
        } // go back a little w/ mogo
        ); 
    
        dlib::move_inches(robot,-13,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 1500,
        .max_voltage = 10000
        } // go back a little w/ mogo
        ); 
    
        dlib::turn_degrees(robot,-228,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 750,
        .max_voltage = 12000
        } //turn to rings  
        ); 


    //!!!!!!!!!!!!!! */ 

    // RED LEFT SIDE AUTO slot 2 !!!!!!!!!!! wip nonconst

   /* BlackWomanMech.move(-1200000);
    pros::delay (800);
    BlackWomanMech.move(0);

    dlib::move_inches(robot,-12,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 670,
    .max_voltage = 8000
    } // go to first mogo
    ); 

    BlackWomanMech.move(1200000);

    dlib::turn_degrees(robot,47,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 650,
    .max_voltage = 12000
    } //turn to rings 
    ); 

    BlackWomanMech.move(0);

    dlib::move_inches(robot,-28,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 900,
    .max_voltage = 6000
    } // go to eat them
    ); 

    mogo.set_value(true); // grab mog
    pros::delay(50);

    dlib::turn_degrees(robot,186,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850,
    .max_voltage = 12000
    } //turn to eat the other one
    ); 
    
    intakeMotor.move(12000); //intake nonstop

    dlib::move_inches(robot,21,{//26
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 2000,
    .max_voltage = 10000
    } // go to eat them
    ); 

    dlib::turn_degrees(robot,160,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850,
    .max_voltage = 12000
    } //turn to eat the other one
    ); 

    dlib::move_inches(robot,11,{//9
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 11000
    } // go to eat them
    ); 

    dlib::move_inches(robot,-26,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850, 
    .max_voltage = 9000
    } // go to eat them
    ); 

    dlib::turn_degrees(robot,125,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850,
    .max_voltage = 12000
    } //turn to eat the other one
    ); 

    dlib::move_inches(robot,21,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 9000
    } // go to eat them
    ); 
    
    dlib::turn_degrees(robot,88,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850,
    .max_voltage = 12000
    } //turn to eat the corner 
    ); 
    
    dlib::move_inches(robot,47,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1900,
    .max_voltage = 9000
        } // go to eat them
    ); 

    dlib::move_inches(robot,-10,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 9000
    } // go to eat them
    ); 

    dlib::move_inches(robot,3,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 9000
    } // go to eat them
    ); 
    
    dlib::move_inches(robot,-3,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 9000
    } // go to eat them
    ); 

    //!!!!!!!!!!!!!!!!! */
    

    //BLUE RIGHT SIDE AUTO slot 3 !!!!!!!  i.e ring side working 2/12
    /* BlackWomanMech.move(-1200000);
    pros::delay (800);
    BlackWomanMech.move(0);

    dlib::move_inches(robot,-12,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 670,
    .max_voltage = 8000
    } // go to first mogo
    ); 

    BlackWomanMech.move(1200000);

    dlib::turn_degrees(robot,-47,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 650,
    .max_voltage = 12000
    } //turn to rings 
    ); 

    BlackWomanMech.move(0);

    dlib::move_inches(robot,-28,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 900,
    .max_voltage = 6000
    } // go to eat them
    ); 

    mogo.set_value(true); // grab mog
    pros::delay(50);

    dlib::turn_degrees(robot,-186,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850,
    .max_voltage = 12000
    } //turn to eat the other one
    ); 
    
    intakeMotor.move(12000); //intake nonstop

    dlib::move_inches(robot,21.5,{//26
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 2000,
    .max_voltage = 10000
    } // go to eat them
    ); 

    dlib::turn_degrees(robot,-160,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850,
    .max_voltage = 12000
    } //turn to eat the other one
    ); 

    dlib::move_inches(robot,10,{//9
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 11000
    } // go to eat them
    ); 

    dlib::move_inches(robot,-25,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850, 
    .max_voltage = 9000
    } // go to eat them
    ); 

    dlib::turn_degrees(robot,-110,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850,
    .max_voltage = 12000
    } //turn to eat the other one
    ); 

    dlib::move_inches(robot,21,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 9000
    } // go to eat them
    ); 
    
    dlib::turn_degrees(robot,-78,{// 88
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850,
    .max_voltage = 12000
    } //turn to eat the corner 
    ); 
    
    dlib::move_inches(robot,47,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1900,
    .max_voltage = 9000
        } // go to eat them
    ); 

    dlib::move_inches(robot,-10,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 9000
    } // go to eat them
    ); 

    dlib::move_inches(robot,7,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 9000
    } // go to eat them
    ); 
        
    dlib::move_inches(robot,-7,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 9000
    } // go to eat them
    ); 
    //!!!!!!!!!!!!!!!!!!!!!!!!!! */


// BLUE LEFT SIDE AUTO slot 4 !!!!!!!!!!!

    /* dlib::move_inches(robot,-29,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 650,
    .max_voltage = 12000
    } // go to first mogo
    ); 

    dlib::turn_degrees(robot,25,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 300,
    .max_voltage = 12000
    } //turn to middle rings
    ); 

    dlib::move_inches(robot,-21,{ //chaged from 12 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 750,
    .max_voltage = 9000
    } // go to middle mogo was 9000
    ); 

    mogo.set_value(true); // grab mog
    intakeMotor.move(12000); //intake nonstop
    pros::delay(150);
    
    dlib::move_inches(robot,5,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 600,
    .max_voltage = 6000
    } // go up a litt w/ mogo
    ); 

    dlib::turn_degrees(robot,-15,{ //WASa
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 550,
    .max_voltage = 12000
    } //turn to rings  
    ); 

    dlib::move_inches(robot,19,{ //changed form 30
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 12700
    } // ram the secondary ring
    ); 

    dlib::move_inches(robot,-5,{ //changed form 30
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 400,
    .max_voltage = 7000
    } // go up a litt w/ mogo
    ); 

    mogo.set_value(false); // ungrab mog
    intakeMotor.move(0); //intake nonstop

    dlib::move_inches(robot,5,{ //changed form 30
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 400,
    .max_voltage = 12000
    } // go up a litt w/ mogo
    ); 

    dlib::turn_degrees(robot,63,{ //WASa
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 550,
    .max_voltage = 12000
    } //turn to rings  
    );

    
    dlib::move_inches(robot,-18,{ //changed form 30
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1000,
    .max_voltage = 6000
    } // go up a litt w/ mogo
    ); 

   mogo.set_value(true); // grab mog

    dlib::move_inches(robot,24.5,{ //changed form 30
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 950,
    .max_voltage = 12000
    } // go up a litt w/ mogo
    ); 

    dlib::turn_degrees(robot,28,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 550,
    .max_voltage = 12000
    } //turn to rings  
    ); 
    
    intakeMotor.move(12000); //intake nonstop

    dlib::move_inches(robot,39,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1800,
    .max_voltage = 7000
    } // go up a litt w/ mogo
    ); 

    dlib::move_inches(robot,-10,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 10000
    } // go back a little w/ mogo
    ); 

    dlib::move_inches(robot,5,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 10000
    } // go back a little w/ mogo
    ); 

    dlib::move_inches(robot,-13,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 1500,
    .max_voltage = 10000
    } // go back a little w/ mogo
    ); 

    /* dlib::turn_degrees(robot,228,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 750,
    .max_voltage = 12000
    } //turn to rings  
    ); 
   //////!!!!!!!!!!! */
    //safe BL
   /* dlib::move_inches(robot,-24,{ //chaged from 12 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 1250,
        .max_voltage = 5000
        } // go to middle mogo was 9000
        ); 

        mogo.set_value(true); // grab mog
        pros::delay(250);
        intakeMotor.move(12000); //intake nonstop

        dlib::turn_degrees(robot,97,{ 
            .error_threshold = 1,
            .settle_ms = 200,
            .max_ms = 750,
            .max_voltage = 12000
        } //turn to rings  
            ); 

            dlib::move_inches(robot,25,{ //chaged from 12 
            .error_threshold = 1,
            .settle_ms = 200,
            .max_ms = 980,
            .max_voltage = 9000
            } // go to middle mogo was 9000
            ); 
        
            dlib::turn_degrees(robot,32,{ 
            .error_threshold = 1,
            .settle_ms = 200,
            .max_ms = 750,
            .max_voltage = 12000
            } //turn to rings  
            ); 

            dlib::move_inches(robot,50,{ //chaged from 12 
            .error_threshold = 1,
            .settle_ms = 200,
            .max_ms = 1500,
            .max_voltage = 9000
            } // go to middle mogo was 9000
            ); 

            dlib::move_inches(robot,-10,{ //chaged from 12 
                    .error_threshold = 1,
                    .settle_ms = 200,
                    .max_ms = 890,
                    .max_voltage = 9000
                    } // go to middle mogo was 9000
            ); 

            dlib::move_inches(robot,10,{ //chaged from 12 
            .error_threshold = 1,
            .settle_ms = 200,
            .max_ms = 890,
            .max_voltage = 9000
            } // go to middle mogo was 9000
            ); 

         dlib::move_inches(robot,-10,{ //chaged from 12 
                            .error_threshold = 1,
                            .settle_ms = 200,
                            .max_ms = 890,
                            .max_voltage = 9000
                            } // go to middle mogo was 9000
                        ); 

    /////*/
    //SKILLS AUTON WIP slot 5 !!!!!!!!!!!!!
    
    BlackWomanMech.move(-1200000);
    pros::delay (800);
    BlackWomanMech.move(0);

    dlib::move_inches(robot,-10,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 690,
    .max_voltage = 7000
    } // go to first mogo
    ); 

    mogo.set_value(true);

    BlackWomanMech.move(1200000);

    dlib::turn_degrees(robot,120,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 750,
    .max_voltage = 12000
    } //turn to rings   infront of ladder
    ); 

    BlackWomanMech.move(0);
    intakeMotor.move(12000); //intake nonstop

    dlib::move_inches(robot,24,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 890,
    .max_voltage = 7000
    } // go to rings 
    ); 

    dlib::turn_degrees(robot,202,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 750,
    .max_voltage = 12000
    } //turn to rings to the right  
    ); 

    dlib::move_inches(robot,20,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 870,
    .max_voltage = 7000
    } // go to eat them
    ); 

    dlib::turn_degrees(robot,167,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 750,
    .max_voltage = 12000
    } //turn to rings to the right  
    ); 

    dlib::move_inches(robot,27,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 870,
    .max_voltage = 7000
    } // go to eat them
    ); 

    dlib::move_inches(robot,-27,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 870,
    .max_voltage = 7000
    } // go to eat them
    ); 

    dlib::turn_degrees(robot,287,{ 
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 850,
    .max_voltage = 12000
    } //turn to rings to the right  
    ); 

    dlib::move_inches(robot,22,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 870,
    .max_voltage = 7000
    } // go to eat them
    ); 

    dlib::move_inches(robot,12,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 870,
    .max_voltage = 7000
    } // go to eat them
    ); 

    dlib::move_inches(robot,-22,{
    .error_threshold = 1,
    .settle_ms = 200,
    .max_ms = 870,
    .max_voltage = 7000
    } // go to eat them
    ); 

    dlib::turn_degrees(robot,247,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 850,
        .max_voltage = 12000
        } //turn to rings to the right  
    );

    dlib::move_inches(robot,13,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 870,
        .max_voltage = 7000
        } // go to eat them
    );  

    dlib::turn_degrees(robot,120,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 850,
        .max_voltage = 12000
        } //turn to rings to the right  
    );

    dlib::move_inches(robot,-19,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 680,
        .max_voltage = 7000
        } // go to eat them
    ); 

    mogo.set_value(false);

    dlib::move_inches(robot,16,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 680,
        .max_voltage = 7000
        } // go to eat them
    ); 
    intakeMotor.move(0); //intake nonstop

    dlib::turn_degrees(robot,220,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 850,
        .max_voltage = 12000
        } //turn to rings to the right  
    );

    dlib::move_inches(robot,-92,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 1100,
        .max_voltage = 7000
        } // go to eat them
    ); 

    dlib::turn_degrees(robot,210,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 850,
        .max_voltage = 12000
        } //turn to rings to the right  
    );
    
    dlib::move_inches(robot,-8,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 750,
        .max_voltage = 7000
        } // go to eat them
    ); 
    //start OF SECOND HALF 
   mogo.set_value(true);

    dlib::turn_degrees(robot,93,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 850,
        .max_voltage = 12000
        } //turn to rings to the right  
    );

    intakeMotor.move(12000); //intake nonstop

    dlib::move_inches(robot,24,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 890,
        .max_voltage = 7000
        } // go to rings 
    ); 

    dlib::turn_degrees(robot,3,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 850,
        .max_voltage = 12000
        } //turn to rings to the right  
    );

    dlib::move_inches(robot,20,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 870,
        .max_voltage = 7000
        } // go to eat them
    ); 

    dlib::turn_degrees(robot,38,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 850,
        .max_voltage = 12000
        } //turn to rings to the right  
    );

    dlib::move_inches(robot,27,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 870,
        .max_voltage = 7000
        } // go to eat them
        ); 
    
    dlib::move_inches(robot,-27,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 870,
        .max_voltage = 7000
        } // go to eat them
    ); 

    dlib::turn_degrees(robot,-82,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 850,
        .max_voltage = 12000
        } //turn to rings to the right  
    );

    dlib::move_inches(robot,22,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 870,
        .max_voltage = 7000
        } // go to eat them
        ); 
    
        dlib::move_inches(robot,12,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 870,
        .max_voltage = 7000
        } // go to eat them
        ); 
    
        dlib::move_inches(robot,-22,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 870,
        .max_voltage = 7000
        } // go to eat them
    ); 

    dlib::turn_degrees(robot,-222,{ 
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 850,
        .max_voltage = 12000
        } //turn to rings to the right  
    );

    dlib::move_inches(robot,13,{
        .error_threshold = 1,
        .settle_ms = 200,
        .max_ms = 870,
        .max_voltage = 7000
        } // go to eat them
    );  
    //!!!!!!!!!!!!!!!!!!!!!!!!!!!! */



    //!!!BASIC COMMANDS 4 DLIB!!!!!!

    /*  dlib::turn_degrees(robot,85,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 99999,
    .max_voltage = 12000
    }
    ); */

    //basic 90 degree turn, BECAUSE OF IMU PLACEMENT EVERYTHIG IS OFF BY 5 DEGREES ^
    /* TURN ANGELS
    
    90 = 85
    180 = 175
    75 = 70
    */
    
/* dlib::move_to(robot, 5, 0, true,{
     .error_threshold = 0,
     .settle_ms = 200,
     .max_ms = 99999,
     .max_voltage = 12000},
     {
     .error_threshold = 0,
     .settle_ms = 200,
     .max_ms = 99999,
     .max_voltage = 12000}

     ); */ // Basic move command ^

  /* dlib::move_inches(robot,24,{
    .error_threshold = 0,
    .settle_ms = 200,
    .max_ms = 99999,
    .max_voltage = 12000
    }
    ); */
   // Basic 1 tile forward movement ^
}

double lift_setpoint = 271;
void lift_task() {
    while (true) {
        if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_R2)) {
            lift_setpoint = 88;
        } else if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_DOWN)) {
            lift_setpoint = 271;
        } else if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_R1)) {
            lift_setpoint = 255;  
        } else if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_RIGHT)) {
            lift_setpoint = 14;
        }

        double measurement = rotsen.get_angle() / 100.0;
        auto error = lift_setpoint - measurement;

        auto pid = dlib::PID({3, 0, 0}, 20);
        double voltage = pid.update(lift_setpoint - measurement);

        BlackWomanMech.move_voltage(voltage);
        pros::delay(20);
    }
}

void opcontrol() {
    dlib::set_mode_brake(robot);
    
    pros::Task lift_task_yay = pros::Task(lift_task);
    
    while(true){
        if(master.get_digital(DIGITAL_L1)){
            intakeMotor.move_voltage(-12000);
        }
        
        // Intake Code
        // If L2 is held down, motor = max reverse speed
        else if(master.get_digital(DIGITAL_L2)){
            intakeMotor.move_voltage(12000);
        }

         // Intake Code
         // Otherwise, dont move at all
        else{
            intakeMotor.move(0);
        }

        // Press A to grab, press again to let go of Mobile Goal
        if(master.get_digital_new_press(DIGITAL_A)){
            wingsActive = !wingsActive;
    
        }

        mogo.set_value(wingsActive);

        if(master.get_digital(DIGITAL_Y)){
            cornerclear = !cornerclear;

            fart.set_value(cornerclear);

            /*if(cornerclear)
                fart.set_value(HIGH);
            else
                fart.set_value(LOW);
            pros::delay(500);*/
        }

         // Press B to up intake, why do this during match?
        if(master.get_digital_new_press(DIGITAL_B)){
            testicles = !testicles;
    
        }

        shit.set_value(testicles);

        /*
       if(master.get_digital(DIGITAL_R2)) //runs motor forward
        {
            BlackWomanMech.move(120);
        }
        else if(master.get_digital(DIGITAL_R1)) //runs motor backward
        { 
            BlackWomanMech.move(-120);
        }
        else 
        {
            BlackWomanMech.set_brake_mode(pros::E_MOTOR_BRAKE_BRAKE); //not pressing anything= everything stops
            BlackWomanMech.brake();
        }

         if(master.get_digital(DIGITAL_B)){ //LOADING STAGE FOR BROWNLADY

            BlackWomanMech.move(-127);
            pros::delay(35);
            BlackWomanMech.move(0);

            
            } 
*/
       /*  if(master.get_digital(pros::E_CONTROLLER_DIGITAL_UP)){
            const double setpoint = 17; //88

            double measurement = rotsen.get_angle() / 100.0;
            auto error = setpoint - measurement;

            auto pid = dlib::PID({1, 0, 0}, 20);
            double voltage = pid.update(setpoint - measurement);

            BlackWomanMech.move_voltage(voltage);

            std::cout << error << ", " << voltage << "\n";
            
        }*/

        // basic arcade using dLib
        double power = master.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
        double turn = master.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_X);
        dlib::arcade(robot, power, turn);

        // to change the left.move / right.move go itno dlib hpp

        dlib::Position position = robot.get_odom().get_position();
        pros::lcd::print(0,"X: %f", position.x);
        pros::lcd::print(1,"Y: %f", position.y);
		pros::lcd::print(2,"Heading: %f", position.theta);
        pros::delay(20);
    }
}
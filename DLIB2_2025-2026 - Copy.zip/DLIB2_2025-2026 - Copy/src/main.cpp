#include "main.h"
#include "au/au.hpp"
#include "dlib/controllers/error_derivative_settler.hpp"
#include "dlib/controllers/error_time_settler.hpp"
#include "dlib/controllers/feedforward.hpp"
#include "dlib/controllers/pid.hpp"
#include "dlib/dlib.hpp"
#include "dlib/hardware/chassis.hpp"
#include "dlib/trajectories/trapezoid_profile.hpp"
#include "dlib/utilities/error_calculation.hpp"
#include "liblvgl/llemu.hpp"
#include "pros/llemu.hpp"
#include "pros/misc.h"
#include <initializer_list>

using namespace au;

class Robot {
public:
	dlib::Chassis chassis;
	dlib::Imu imu;

	dlib::Odometry odom;
	std::unique_ptr<pros::Task> odom_updater;

	dlib::Pid<Meters> move_pid;
	dlib::ErrorDerivativeSettler<Meters> move_settler;

	dlib::Pid<Degrees> turn_pid;
	dlib::ErrorDerivativeSettler<Degrees> turn_settler;

	Robot(
		dlib::ChassisConfig chassis_config, 
		dlib::ImuConfig imu_config,
		dlib::PidConfig move_pid_config,
		dlib::ErrorDerivativeSettler<Meters> move_pid_settler,
		dlib::PidConfig turn_pid_config,
		dlib::ErrorDerivativeSettler<Degrees> turn_pid_settler
	) : 
		chassis(chassis_config), 
		imu(imu_config),
		move_pid(move_pid_config),
		move_settler(move_pid_settler),
		turn_pid(turn_pid_config),
		turn_settler(turn_pid_settler),
		odom() {

	}

	void calibrate_imu() {
		imu.initialize();
	}

	// Odom task
	void start_odom() {
		chassis.initialize();

		odom_updater = std::make_unique<pros::Task>([this]() {
			while (true) {
				odom.update(
					chassis.left_motors_displacement(), 
					chassis.right_motors_displacement(), 
					ZERO,
					imu.get_rotation()
				);

				pros::delay(20);
			}
		});
	}

	// Use PID to do a relative movement
		/////
	 void move_with_pid(double displacement, double max_time = 3000, int max_voltage = 12000) {
        auto target_displacement = inches(displacement);

        double elapsed_time = 0;    

        move_pid.reset();
        move_settler.reset();

        auto last_error = inches(displacement);
        auto reading = chassis.forward_motor_displacement();

        while (!move_settler.is_settled(move_pid.get_error(), move_pid.get_derivative())) {
			auto reading = chassis.forward_motor_displacement();
            auto error = dlib::linear_error(inches(displacement), reading);

            if (elapsed_time > max_time) {
                chassis.brake();
                std::cout << "timed out" << "\n";
                break;
            }

            auto voltage = move_pid.update(error, milli(seconds)(20));

            std::cout << voltage << std::endl;

            chassis.move_voltage(voltage);

            last_error = error;
			
            elapsed_time += 20;

			pros::lcd::print(5, "error: %f, voltage: %f", error, voltage);
			pros::lcd::print(6, "moving...");
            pros::delay(20);
        }


		pros::lcd::print(6, "settled");
		
        chassis.left_motors.raw.brake();
        chassis.right_motors.raw.brake();
    }
	
	
	void turn_with_pid(Quantity<Degrees, double> heading) {
		auto target_heaidng = heading;

		turn_pid.reset();
		turn_settler.reset();

		while (!turn_settler.is_settled(turn_pid.get_error(), turn_pid.get_derivative())) {
			auto error = dlib::angular_error(heading, imu.get_rotation());
			auto voltage = turn_pid.update(error, milli(seconds)(20));
			
			chassis.turn_voltage(voltage);

			pros::delay(20);
		}
	}
		////////////
	void turn_with_pid(double heading, double max_time = 3000, int max_voltage = 12000) {
        auto target_heading = au::degrees(heading);

        double elapsed_time = 0;    

        turn_pid.reset();
        turn_settler.reset();

        auto voltage = volts(0.0);

        auto last_error = degrees(heading);
        auto reading = imu.get_rotation();

        while (!turn_settler.is_settled(turn_pid.get_error(), turn_pid.get_derivative())) {

            auto error = dlib::angular_error((au::degrees)(heading), imu.get_rotation());

            if (elapsed_time > max_time) {
                chassis.brake();
                std::cout << "timed out" << "\n";
                break;
            }

            voltage = turn_pid.update(error, milli(seconds)(20));
            std::cout << voltage << std::endl;
            
            if(au::abs(voltage) > milli(volts)(max_voltage)){
                if(voltage > volts(0)){
                    voltage = milli(volts)(max_voltage);
                }
                else{
                    voltage = milli(volts)(-max_voltage);
                }
            }

            std::cout << "target:" << heading << ", " << "current:" << imu.get_heading() << ", " << "error: " << error << ", voltage:" << voltage << std::endl;
            chassis.turn_voltage(voltage);

            last_error = error;

            elapsed_time += 20;
            pros::delay(20);
        }

        std::cout << "settled with voltage: " << voltage << "\n";
        chassis.left_motors.raw.brake();
        chassis.right_motors.raw.brake();
    }
		////////////
	void turn_with_pid(double heading) {
		turn_with_pid(degrees(heading));
	}

	void turn_to_point(dlib::Vector2d point) {
		auto angle = odom.angle_to(point);
		turn_with_pid(angle);
	}

	void turn_to_point(double x, double y) {
		turn_to_point({inches(x), inches(y)});
	}

	void move_to_point(dlib::Vector2d point) {
		turn_to_point(point);

		auto displacement = odom.displacement_to(point);
	}

	void move_to_point(double x, double y) {
		move_to_point({inches(x), inches(y)});
	}
};

// Create a config for everything used in the Robot class
pros::Motor intakeMotor(-6,pros::v5::MotorGears::blue);
pros::adi::DigitalOut mogo('h', false);
pros::adi::DigitalOut fart('f', false);
pros::adi::DigitalOut shit('a', false);
pros::Motor BlackWoaman1 (3);
pros::Motor BlackWoaman2 (-8);
pros::MotorGroup BlackWomanMech ({3,-8});

bool wingsActive = false;
bool cornerclear = false;
bool testicles = false;

dlib::ChassisConfig chassis_config = dlib::ChassisConfig::from_drive_rpm(
	{{-17, 5, -15}},	// left motors
	{{-18, 12, 13}},	// right motors
	pros::MotorGearset::blue,
	rpm(450),	// the drivebase rpm
	inches(3.25)	// the drivebase wheel diameter
);

dlib::ImuConfig imu_config {
	4,	// imu port
	1.01107975	// optional imu scaling constant
};

dlib::PidConfig move_pid_config {
	{
		35, 	// kp, porportional gain
		-0.02, 	// ki, integral gain
		1	// kd, derivative gain
	}
};

dlib::ErrorDerivativeSettler<Meters> move_pid_settler {
	meters(0.01),		// error threshold, the maximum error the pid can settle at
	meters_per_second(0.01) // derivative threshold, the maximum instantaneous error over time the pid can settle at
};

dlib::PidConfig turn_pid_gains {
	{
		-10, 	// kp, porportional gain //-10 + 0.08 = good but slow  //-15
		1, 	// ki, integral gain
		0.09 // kd, derivative gain //0.08 //0.28	
	}
};

dlib::ErrorDerivativeSettler<Degrees> turn_pid_settler {
	degrees(1),		// error threshold, the maximum error the pid can settle at
	degrees_per_second(1)	// derivative threshold, the maximum instantaneous error over time the pid can settle at
};

Robot robot = Robot(
	chassis_config,
	imu_config,
	move_pid_config,
	move_pid_settler,
	turn_pid_gains,
	turn_pid_settler
);

void on_center_button() {}

void initialize() {
	pros::lcd::initialize();

	auto profile = dlib::TrapezoidProfile<Meters>::from_constraints(
		centi(meters)(60),
		meters_per_second(1.5),
		meters_per_second_squared(3)
	);

	profile.calculate(seconds(0));
	
	robot.calibrate_imu();
	robot.start_odom();
}

void disabled() {}

void competition_initialize() {

}


void autonomous() {
	

	// Try a movement!
	// DLIB 2 COMMANDS
	// X and Y are in inches (check overloads above)
	// NEGATIVE VALUES TURN RIGHT, POS LEFT
	//robot.turn_with_pid(degrees(87)); 87 IS TRUE 90
	//robot.turn_with_pid(degrees(90));
	//robot.move_with_pid(inches(60)); 
	// robot.move_to_point(24, 24);
	//robot.move_with_pid(inches(-24)); 

	/// TWO BIG COMMANDS 
	/* robot.turn_with_pid(87,3000,12000);
	robot.move_with_pid(24,3000,12000); */
	//robot.turn_with_pid(87,3000,12000);
	/* robot.move_with_pid(-12,1000,8000);*/
	
	robot.move_with_pid(15,3000,6000);
	robot.turn_with_pid(87,3000,12000);
	robot.move_with_pid(-15,3000,6000);
}


void opcontrol() {
robot.chassis.left_motors.raw.set_brake_mode(pros::E_MOTOR_BRAKE_BRAKE);
robot.chassis.right_motors.raw.set_brake_mode(pros::E_MOTOR_BRAKE_BRAKE);

	while(true){
		// Try arcade drive code!
		pros::Controller master = pros::Controller(pros::E_CONTROLLER_MASTER);

 		if(master.get_digital(DIGITAL_L1)){
            intakeMotor.move_voltage(12000);
        }
        
        // Intake Code
        // If L2 is held down, motor = max reverse speed
        else if(master.get_digital(DIGITAL_L2)){
            intakeMotor.move_voltage(-12000);
        }

         // Intake Code
         // Otherwise, dont move at all
        else{
            intakeMotor.move(0);
        }

		// Press A to grab, press again to let go of Mobile Goal
        if(master.get_digital_new_press(DIGITAL_A)){
            wingsActive = !wingsActive;
    
        }

        mogo.set_value(wingsActive);

		
		//y TO USE CORNER CLEAR
		if(master.get_digital(DIGITAL_Y)){
            cornerclear = !cornerclear;

            fart.set_value(cornerclear);
		}

		// Press B to up intake, why do this during match?
        if(master.get_digital_new_press(DIGITAL_B)){
            testicles = !testicles;
    
        }

        shit.set_value(testicles);

		if(master.get_digital(DIGITAL_R2)) //runs motor forward
        {
            BlackWomanMech.move(120);
        } else if(master.get_digital(DIGITAL_R1)) //runs motor backward
        { 
            BlackWomanMech.move(-120);
        } else 
        {
            BlackWomanMech.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD); //not pressing anything= everything stops
            BlackWomanMech.brake();
        }

		if(master.get_digital(DIGITAL_B)){ //LOADING STAGE FOR BROWNLADY

        BlackWomanMech.move(127);
        pros::delay(30);
        BlackWomanMech.move(0);

            }
		//arcade

		// get power and turn
		double power = master.get_analog(ANALOG_LEFT_Y);
		double turn = master.get_analog(ANALOG_RIGHT_X);
		// arcade movement
		robot.chassis.arcade(power, -turn);
		if(power + turn == 0){
			robot.chassis.brake();
		}

		auto position = robot.odom.get_position();
        pros::lcd::print(0,"X: %f", position.x);
        pros::lcd::print(1,"Y: %f", position.y);
		pros::lcd::print(2,"Heading: %f", position.theta);
        pros::delay(20);
	}
}
	

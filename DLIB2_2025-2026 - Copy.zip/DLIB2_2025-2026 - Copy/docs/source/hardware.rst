Hardware
========

.. doxygenclass:: dlib::Chassis
    :project: dlib
    :members:

.. doxygenclass:: dlib::MotorGroup
    :project: dlib
    :members:

.. doxygenclass:: dlib::Motor
    :project: dlib
    :members:

.. doxygenclass:: dlib::Imu
    :project: dlib
    :members:

.. doxygenclass:: dlib::Rotation
    :project: dlib
    :members:

.. doxygenclass:: dlib::Timer
    :project: dlib
    :members:
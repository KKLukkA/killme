API
===

.. toctree::
    :maxdepth: 5
    :caption: API Reference

    hardware
    control
    kinematics
    trajectories
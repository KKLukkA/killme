.. dlib documentation master file, created by
   sphinx-quickstart on Sun Nov  3 19:02:15 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

dlib documentation
==================

Actual docs goes crazy


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api
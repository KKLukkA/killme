Kinematics
==========

.. doxygenstruct:: dlib::Vector2d
    :project: dlib
    :members:

.. doxygenstruct:: dlib::Pose2d
    :project: dlib
    :members:

.. doxygenclass:: dlib::Odometry
    :project: dlib
    :members:
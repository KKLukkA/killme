#pragma once

#include "au/au.hpp"
#include "pros/abstract_motor.hpp"
namespace dlib {

au::Quantity<au::Rpm, double> gearset_rpm(pros::MotorGearset gearset);

}